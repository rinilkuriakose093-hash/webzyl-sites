// CLOUDFLARE WORKER - Booking API Endpoint
// Phase 4: Booking Enquiry Backend
// File: worker.js (add to existing worker or create new route)

/**
 * POST /api/booking
 * Handles booking enquiry submissions
 * 
 * Architecture:
 * Browser → Worker (validate + rate limit) → Apps Script → Sheets
 */

// Rate limiting store (in-memory for this worker instance)
const rateLimitStore = new Map();

// Configuration
const CONFIG = {
  RATE_LIMIT: {
    MAX_REQUESTS: 5,
    WINDOW_MINUTES: 60
  },
  APPS_SCRIPT_URL: '', // Set via environment variable: BOOKING_WEBHOOK_URL
  HMAC_SECRET: '' // Set via environment variable: BOOKING_HMAC_SECRET
};

/**
 * Main handler for booking endpoint
 */
async function handleBookingRequest(request, env) {
  // Only accept POST
  if (request.method !== 'POST') {
    return jsonResponse({ success: false, message: 'Method not allowed' }, 405);
  }

  try {
    // Parse request body
    const bookingData = await request.json();
    
    // Get client IP and headers for rate limiting and audit
    const clientIP = request.headers.get('CF-Connecting-IP') || 'unknown';
    const userAgent = request.headers.get('User-Agent') || 'unknown';
    const cfRay = request.headers.get('CF-Ray') || 'unknown';
    
    // STEP 1: Rate Limiting
    const rateLimitKey = `${bookingData.slug}:${clientIP}`;
    if (isRateLimited(rateLimitKey)) {
      return jsonResponse({
        success: false,
        message: 'Too many requests. Please try again in an hour.'
      }, 429);
    }
    
    // STEP 2: Validate required fields
    const validation = validateBookingData(bookingData);
    if (!validation.valid) {
      return jsonResponse({
        success: false,
        message: validation.error
      }, 400);
    }
    
    // STEP 3: Fetch config from KV to verify slug and status
    const config = await env.RESORT_CONFIGS.get(`config:${bookingData.slug}`, { type: 'json' });
    
    if (!config) {
      return jsonResponse({
        success: false,
        message: 'Invalid resort identifier'
      }, 404);
    }
    
    if (config.status !== 'active') {
      return jsonResponse({
        success: false,
        message: 'Bookings are currently unavailable'
      }, 403);
    }
    
    // STEP 4: Enrich booking data with metadata
    const enrichedData = {
      ...bookingData,
      timestamp: new Date().toISOString(),
      source_ip: clientIP,
      user_agent: userAgent,
      cf_ray: cfRay,
      config_version: config.updatedAt || 'unknown'
    };
    
    // STEP 5: Get booking mode from config
    const bookingMode = config.booking?.mode || 'sheet';
    const sheetName = config.booking?.sheetName || generateSheetName();
    
    // STEP 6: Forward to Apps Script (if sheet mode or both)
    let appsScriptSuccess = false;
    if (bookingMode === 'sheet' || bookingMode === 'both') {
      try {
        const appsScriptUrl = env.BOOKING_WEBHOOK_URL;
        if (!appsScriptUrl) {
          console.error('BOOKING_WEBHOOK_URL not configured');
        } else {
          // Create HMAC signature for security
          const signature = await createHMAC(enrichedData, env.BOOKING_HMAC_SECRET);
          
          const appsScriptResponse = await fetch(appsScriptUrl, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'X-Signature': signature,
              'X-Sheet-Name': sheetName
            },
            body: JSON.stringify(enrichedData)
          });
          
          appsScriptSuccess = appsScriptResponse.ok;
          
          if (!appsScriptSuccess) {
            console.error('Apps Script error:', await appsScriptResponse.text());
          }
        }
      } catch (error) {
        console.error('Failed to forward to Apps Script:', error);
      }
    }
    
    // STEP 7: Generate WhatsApp URL (if whatsapp mode or both)
    let whatsappUrl = null;
    if (bookingMode === 'whatsapp' || bookingMode === 'both') {
      const phone = config.contact?.phone || config.social?.whatsapp || '';
      if (phone) {
        const template = config.booking?.whatsappTemplate || 
          'Hi, I want to enquire about {{room}} from {{checkIn}} to {{checkOut}}';
        
        const message = fillWhatsAppTemplate(template, enrichedData);
        whatsappUrl = `https://wa.me/${cleanPhoneNumber(phone)}?text=${encodeURIComponent(message)}`;
      }
    }
    
    // STEP 8: Record rate limit
    recordRateLimit(rateLimitKey);
    
    // STEP 9: Return success response
    return jsonResponse({
      success: true,
      message: 'Your enquiry has been received successfully',
      whatsappUrl: whatsappUrl,
      mode: bookingMode,
      recorded: appsScriptSuccess || bookingMode === 'whatsapp'
    }, 200);
    
  } catch (error) {
    console.error('Booking error:', error);
    return jsonResponse({
      success: false,
      message: 'An error occurred processing your request'
    }, 500);
  }
}

/**
 * Validate booking data
 */
function validateBookingData(data) {
  // Required fields
  if (!data.slug || typeof data.slug !== 'string') {
    return { valid: false, error: 'Invalid resort identifier' };
  }
  
  if (!data.name || data.name.trim().length < 2) {
    return { valid: false, error: 'Name is required' };
  }
  
  // At least one contact method
  if (!data.email && !data.phone) {
    return { valid: false, error: 'Email or phone is required' };
  }
  
  // Email format (if provided)
  if (data.email && !isValidEmail(data.email)) {
    return { valid: false, error: 'Invalid email format' };
  }
  
  // Phone format (if provided)
  if (data.phone && !isValidPhone(data.phone)) {
    return { valid: false, error: 'Invalid phone format' };
  }
  
  // Date validation
  if (!data.checkIn || !data.checkOut) {
    return { valid: false, error: 'Check-in and check-out dates are required' };
  }
  
  const checkIn = new Date(data.checkIn);
  const checkOut = new Date(data.checkOut);
  
  if (isNaN(checkIn.getTime()) || isNaN(checkOut.getTime())) {
    return { valid: false, error: 'Invalid date format' };
  }
  
  if (checkIn >= checkOut) {
    return { valid: false, error: 'Check-out must be after check-in' };
  }
  
  // Guests validation
  if (!data.guests || data.guests < 1 || data.guests > 50) {
    return { valid: false, error: 'Number of guests must be between 1 and 50' };
  }
  
  // Notes length check
  if (data.notes && data.notes.length > 1000) {
    return { valid: false, error: 'Notes too long' };
  }
  
  return { valid: true };
}

/**
 * Rate limiting using in-memory store
 */
function isRateLimited(key) {
  const now = Date.now();
  const windowMs = CONFIG.RATE_LIMIT.WINDOW_MINUTES * 60 * 1000;
  
  if (!rateLimitStore.has(key)) {
    return false;
  }
  
  const requests = rateLimitStore.get(key);
  // Remove old requests outside the time window
  const recentRequests = requests.filter(timestamp => now - timestamp < windowMs);
  
  rateLimitStore.set(key, recentRequests);
  
  return recentRequests.length >= CONFIG.RATE_LIMIT.MAX_REQUESTS;
}

function recordRateLimit(key) {
  const now = Date.now();
  const existing = rateLimitStore.get(key) || [];
  existing.push(now);
  rateLimitStore.set(key, existing);
}

/**
 * Generate sheet name in format: Bookings_YYYY_MM
 */
function generateSheetName() {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  return `Bookings_${year}_${month}`;
}

/**
 * Create HMAC signature for Apps Script authentication
 */
async function createHMAC(data, secret) {
  if (!secret) return 'no-secret';
  
  const encoder = new TextEncoder();
  const keyData = encoder.encode(secret);
  const messageData = encoder.encode(JSON.stringify(data));
  
  const key = await crypto.subtle.importKey(
    'raw',
    keyData,
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  );
  
  const signature = await crypto.subtle.sign('HMAC', key, messageData);
  const hashArray = Array.from(new Uint8Array(signature));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

/**
 * Fill WhatsApp template with booking data
 */
function fillWhatsAppTemplate(template, data) {
  return template
    .replace(/\{\{name\}\}/g, data.name)
    .replace(/\{\{room\}\}/g, data.roomType || 'a room')
    .replace(/\{\{checkIn\}\}/g, data.checkIn)
    .replace(/\{\{checkOut\}\}/g, data.checkOut)
    .replace(/\{\{guests\}\}/g, data.guests)
    .replace(/\{\{notes\}\}/g, data.notes || '');
}

/**
 * Clean phone number (remove non-digits)
 */
function cleanPhoneNumber(phone) {
  return phone.replace(/\D/g, '');
}

/**
 * Validate email format
 */
function isValidEmail(email) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

/**
 * Validate phone format
 */
function isValidPhone(phone) {
  const cleaned = cleanPhoneNumber(phone);
  return cleaned.length >= 10 && cleaned.length <= 15;
}

/**
 * JSON response helper
 */
function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*', // Configure as needed
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type'
    }
  });
}

/**
 * Handle OPTIONS for CORS
 */
function handleOptions() {
  return new Response(null, {
    status: 204,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
      'Access-Control-Max-Age': '86400'
    }
  });
}

// Export for use in main worker
export { handleBookingRequest, handleOptions };

// Example integration with main worker:
/*
addEventListener('fetch', event => {
  event.respondWith(handleRequest(event.request, event));
});

async function handleRequest(request, event) {
  const url = new URL(request.url);
  
  // Handle booking endpoint
  if (url.pathname === '/api/booking') {
    if (request.method === 'OPTIONS') {
      return handleOptions();
    }
    return handleBookingRequest(request, event.env || {});
  }
  
  // Handle other routes...
  return new Response('Not Found', { status: 404 });
}
*/
